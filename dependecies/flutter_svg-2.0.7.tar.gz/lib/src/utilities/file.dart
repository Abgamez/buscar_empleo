export '_file_io.dart' if (dart.library.html) '_file_none.dart';
