export '_http_io.dart' if (dart.library.html) '_http_web.dart';
