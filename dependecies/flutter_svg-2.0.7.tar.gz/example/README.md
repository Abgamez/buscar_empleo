# example

A new Flutter project.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).

## Benchmarking

`flutter drive --profile --endless-trace-buffer --target test_driver/bench.dart`
